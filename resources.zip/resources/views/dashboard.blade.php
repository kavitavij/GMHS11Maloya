<x-app-layout>
@livewire('admins.AdminNavbar')
</x-app-layout>