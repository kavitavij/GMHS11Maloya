<div>
  @livewire('header')
  <nav className="navbar navbar-expand-lg navbar-light bg-light">
    <div className="container-fluid acolor ">
      <div className="collapse navbar-collapse " id="navbarSupportedContent">
        <ul class="nav  nav-tabs" id="myTab" role="tablist">
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Home</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link " id="slider-tab" data-bs-toggle="tab" data-bs-target="#slider" type="button" role="tab" aria-controls="slider" aria-selected="true">Slider</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Principal-tab" data-bs-toggle="tab" data-bs-target="#Principal" type="button" role="tab" aria-controls="Principal" aria-selected="false">Principal Desk </button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Infrastucture-tab" data-bs-toggle="tab" data-bs-target="#Infrastucture" type="button" role="tab" aria-controls="Infrastucture" aria-selected="false">Infrastucture</button>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">CBSE</a>
            <ul class="dropdown-menu">
              <li><button class="nav-link" id="Affiliation-tab" data-bs-toggle="tab" data-bs-target="#Affiliation" type="button" role="tab" aria-controls="Affiliation" aria-selected="false">Affiliation Status</button></li>
              <li><button class="nav-link" id="Transfer-tab" data-bs-toggle="tab" data-bs-target="#Transfer" type="button" role="tab" aria-controls="Transfer" aria-selected="false">Transfer Certificate</button></li>
              <li><button class="nav-link" id="Result-tab" data-bs-toggle="tab" data-bs-target="#Result" type="button" role="tab" aria-controls="Result" aria-selected="false">Result</button></li>

            </ul>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Mandatory-tab" data-bs-toggle="tab" data-bs-target="#Mandatory" type="button" role="tab" aria-controls="Mandatory" aria-selected="false">Mandatory Disclosure</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Events-tab" data-bs-toggle="tab" data-bs-target="#Events" type="button" role="tab" aria-controls="Events" aria-selected="false">Events</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Curriculum-tab" data-bs-toggle="tab" data-bs-target="#Curriculum" type="button" role="tab" aria-controls="Curriculum" aria-selected="false">Curriculum</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Gallery-tab" data-bs-toggle="tab" data-bs-target="#Gallery" type="button" role="tab" aria-controls="Gallery" aria-selected="false">Gallery</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Contact-tab" data-bs-toggle="tab" data-bs-target="#Contact" type="button" role="tab" aria-controls="Contact" aria-selected="false">Contact Us</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="About-tab" data-bs-toggle="tab" data-bs-target="#About" type="button" role="tab" aria-controls="About" aria-selected="false">About Us</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Faculty-tab" data-bs-toggle="tab" data-bs-target="#Faculty" type="button" role="tab" aria-controls="Faculty" aria-selected="false">Faculty</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Faculty-tab" data-bs-toggle="tab" data-bs-target="#School_Detail" type="button" role="tab" aria-controls="School_Detail" aria-selected="false">School Detail</button>
          </li>
          <li class="nav-item" role="presentation" wire:ignore>
            <button class="nav-link" id="Faculty-tab" data-bs-toggle="tab" data-bs-target="#NavBar" type="button" role="tab" aria-controls="NavBar" aria-selected="false">NavBar </button>
          </li>
          <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <li class="nav-item" role="presentation" wire:ignore>
                    <a href="route('logout')" class="nav-link"
                            onclick="event.preventDefault();
                                        this.closest('form').submit();" class="nav-item">
                        {{ __('Log Out') }}
                    </a>
                    </li>
                </form>
        </ul>

        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab" wire:ignore.self>@livewire('admins.admin-home')</div>
          <div class="tab-pane fade show " id="slider" role="tabpanel" aria-labelledby="slider-tab" wire:ignore.self>@livewire('admins.AddSlider')</div>
          <div class="tab-pane fade" id="Principal" role="tabpanel" aria-labelledby="Principal-tab" wire:ignore.self>
            @livewire('admins.principal-desk-data')
          </div>
          <div class="tab-pane fade" id="Infrastucture" role="tabpanel" aria-labelledby="Infrastucture-tab" wire:ignore.self>@livewire('admins.Infrastucture')</div>
          <div class="tab-pane fade" id="Affiliation" role="tabpanel" aria-labelledby="Affiliation-tab" wire:ignore.self>@livewire('admins.affiliation')</div>
          <div class="tab-pane fade" id="Transfer" role="tabpanel" aria-labelledby="Transfer-tab" wire:ignore.self>Transfer</div>
          <div class="tab-pane fade" id="Result" role="tabpanel" aria-labelledby="Result-tab" wire:ignore.self>@livewire('admins.result')</div>
          <div class="tab-pane fade" id="Mandatory" role="tabpanel" aria-labelledby="Mandatory-tab" wire:ignore.self>@livewire('admins.mandatory-disclosure')</div>
          <div class="tab-pane fade" id="Events" role="Events" aria-labelledby="Events-tab" wire:ignore.self>@livewire('admins.event')</div>
          <div class="tab-pane fade" id="Curriculum" role="Curriculum" aria-labelledby="Curriculum-tab" wire:ignore.self>@livewire('admins.Curriculum')</div>
          <div class="tab-pane fade" id="Gallery" role="Gallery" aria-labelledby="Gallery-tab" wire:ignore.self>	@livewire('admins.UploadImageCategory')</div>
          <div class="tab-pane fade" id="Contact" role="Contact" aria-labelledby="Contact-tab" wire:ignore.self>	@livewire('admins.UploadContactus')</div>
          <div class="tab-pane fade" id="About" role="About" aria-labelledby="About-tab" wire:ignore.self>	@livewire('admins.UploadAboutus')</div>
          <div class="tab-pane fade" id="Faculty" role="Faculty" aria-labelledby="Faculty-tab" wire:ignore.self>	@livewire('admins.UploadTeacher')</div>
          <div class="tab-pane fade" id="School_Detail" role="School_Detail" aria-labelledby="School_Detail-tab" wire:ignore.self>	@livewire('admins.UploadSchoolDetails')</div>
          <div class="tab-pane fade" id="NavBar" role="NavBar" aria-labelledby="NavBar-tab" wire:ignore.self>	@livewire('admins.AddNavbar')</div>
        </div>

      </div>
    </div>
</div>
</nav>

</div>