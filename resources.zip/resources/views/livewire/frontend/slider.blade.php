<div>
    <div id="carouselExampleCaptions" class="carousel slide pt-2" onmouseover="this.stop();"  data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="4" aria-label="Slide 5"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="5" aria-label="Slide 6"></button>
        </div>
        <div class="carousel-inner" >
            <!-- <div class="carousel-item active">
                <img src="/images/ULLAS.png"  class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                </div>
            </div> -->
            @foreach ($slider as $data)
            <div class="carousel-item active" >
                <img src="{{asset('storage/images/'.$data['slider_image'])}}" class="d-block w-100" alt="{{$data->slider_image}}" class="d-block w-100" >
            </div>
            @endforeach
           
        </div>
    </div>
</div>