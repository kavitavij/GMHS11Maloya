<div>
    <div class="middle_container">
        <div className="table_container">
            <span>

                <h3 style="color: #F65314">Address</h3>
                @if(count($data) > 0)
                @foreach ($data as $data)
                {{$data->address}}
                <br />
                <b> Contact No:</b> {{$data->phone_number}}
                <br />
                <b> Email :</b>{{$data->email}}
                <br />
                <iframe src="{{$data->map}}" width="1100" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                @endforeach
                @else
                <td colspan="2" align="center">
                    No Data Found.
                </td>
                @endif
            </span>
        </div>
    </div>
</div>