<div>
    <div className="middle_container">
        <div className="left_content">
            <div className="table_container">
                <span>
                    <h3 class="pt-4" style="color: #F65314;">Mandatory Disclosure </h3>
                    @if(count($mandatorydata) > 0)
                    @foreach ($mandatorydata as $data)
                    <a href="{{ asset('storage/files/' .$data['file'] ) }}">
                        <i class="fas fa-arrow-circle-right" style="color: #eb511e"></i>
                        {{$data->file_name}}
                    </a>
                    <br />
                    @endforeach
                    @else
                    <td colspan="2" align="center">
                        No Data Found.
                    </td>
                    @endif

                </span>
            </div>
        </div>
    </div>
</div>