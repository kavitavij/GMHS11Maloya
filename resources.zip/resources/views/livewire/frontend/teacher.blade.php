<div>
    <div class="table_container">
        <h3 class="pt-4 mr-lg-5" style="color: #F65314; "> Staff Details </h3>
        <table class="gallery_detail">
            <thead>
                <tr style="background-color: #56767f; color: #fff">
                    <th>Teacher Name</th>
                    <th>Designation</th>
                    <th>Qualification</th>
                    <th>Assign Classes</th>
                    <th>Assign Subjects</th>
                </tr>
            </thead>
            <tbody>
                @if(count($teacherdata) > 0)
                @foreach ($teacherdata as $data)
                <tr style="background-color: #eee">
                    <td>{{$data->teacher_name}}</td>
                    <td>{{$data->designation}}</td>
                    <td>{{$data->qualification}}</td>
                    <td> {{$data->assign_class}}</td>
                    <td>{{$data->assign_subject}}</td>
                </tr>
                @endforeach
                @else
                <td colspan="7" align="center">
                    No Data Found.
                </td>
                @endif
            </tbody>
        </table>
    </div>
</div>