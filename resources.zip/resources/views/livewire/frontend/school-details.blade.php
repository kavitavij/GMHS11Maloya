<div>
    <div className="middle_container">
        <div className="left_content">
            <div className="table_container">
                <span>
                    <h3 class="pt-4 mr-lg-5" style="color: #F65314; ">School Details</h3>
                    @if(count($school_details) > 0)
                    @foreach ($school_details as $data)

                    <table class="table ">
                        <tbody>
                            <tr>
                                <th scope="row">Affiliation Number</th>
                                <th>{{$data->affiliation_number}}</th>
                            </tr>
                            <tr>
                                <th scope="row">Affiliation Validity</th>
                                <th> {{$data->affiliation_validity}} </th>
                            </tr>
                            <tr>
                                <th scope="row">School Code</th>
                                <th> {{$data->school_code}} </th>
                            </tr>
                            <tr>
                                <th scope="row">Name of The School</th>
                                <th> {{$data->school_name}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> Address of The School</th>
                                <th> {{$data->address}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> Name of The Principal</th>
                                <th> {{$data->principal_name}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> Principal Contact Number</th>
                                <th> {{$data->principal_contact_number}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> Principal Retirement Date</th>
                                <th> {{$data->principal_retirement_date}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> School Contact Number</th>
                                <th> {{$data->school_contact_number}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> School Email ID</th>
                                <th> {{$data->school_email}} </th>
                            </tr>
                            <tr>
                                <th scope="row"> School Website</th>
                                <th> {{$data->school_website}} </th>
                            </tr>
                            <tr>
                                <th scope="row">Land Mark Near School</th>
                                <th> {{$data->landmark}} </th>
                            </tr>
                            <tr>
                                <th scope="row">Year of Estsblishment of School</th>
                                <th> {{$data->estsblishment_year}} </th>
                            </tr>
                        </tbody>
                    </table>

                    @endforeach
                    @else
                    <td colspan="2" align="center">
                        No Data Found.
                    </td>
                    @endif
            </div>
        </div>
    </div>
</div>