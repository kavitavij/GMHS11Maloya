<div>
    <div className="middle_container">
        <div className="left_content">
            <div className="table_container">
                <span>
                    <h3 class="pt-4" style="color: #F65314;">School Enrollments and Houses </h3>
                    <td colspan="7" align="center">Presently No List Available</td>
            </div>
        </div>
    </div>
</div>