<div>
    <div className="middle_container">
        <div className="left_content">
            <div className="table_container">
                @if(count($aboutdata) > 0)
                @foreach ($aboutdata as $data)

                <span>
                    <h3 class="pt-4" style="color: #F65314;">{{$data->header}}</h3>
                    {{$data->description}}
                </span>
                @endforeach
                @else
                <td colspan="2" align="center">
                    No Data Found.
                </td>
                @endif
            </div>
        </div>
    </div>
</div>