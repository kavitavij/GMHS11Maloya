<div>
    <div class="middle_container">
        <div class="left_content">
            <div class="table_container">
                <span>
                    @if(count($data) > 0)
                    @foreach ($data as $data)
                    <h3> {{$data->heading}}</h3>

                    <img src="{{asset('storage/images/'.$data['image'])}}" alt="{{$data->image}}" style="box-shadow: 3px 3px 3px 3px #666; float: left; margin: 10px 20px 10px 10px" height=300 width=300 />

                    {{$data->description}}

                    @endforeach
                    @else
                    <td colspan="2" align="center">
                        No Data Found.
                    </td>
                    @endif
                </span>
            </div>
        </div>
    </div>
</div>