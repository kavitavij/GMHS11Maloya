<div>
  
  <div class="header">
    @if(count($data) > 0)
    @foreach ($data as $data)
    <div class="logo">
      <img src="{{asset('storage/images/'.$data['logo_1'])}}" alt="{{$data->logo_1}}" width="100px" />

    </div>
    <div class="text_logo">
      <h1>
        <a href="/" style="color:#fff">{{$data->school_name}}</a>
      </h1>
      <h3>{{$data->school_address}} </h3>
    </div>
    <div class="logo2">
      <img src="{{asset('storage/images/'.$data['logo_2'])}}"  alt="{{$data->logo_2}}" width="100px" />
    </div>
    @endforeach
    @else
    <td colspan="2" align="center">
      No Data Found.
    </td>
    @endif
  </div>
  <span class="stext mt-1">What's New</span>
    <marquee class="notification mt-1" style="width: 92%" onmouseover="this.stop();" onmouseout="this.start();">
        <a href="{{ asset('/storage/files/' .$marqueeData['file'] ) }}" class="marquee-data" target="_blank">
            <img src="/images/gif-new.gif" height="24px" />
            {{$marqueeData->file_name}}
        </a>
    </marquee>
</div>