<?php

namespace App\Livewire\Admins;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Image_Category;
use App\Models\Image;

class UploadGallery extends Component
{
    use WithFileUploads;
    public $data , $image_categorys_id , $image ;
    public function render()
    {
        $this->data= Image_Category::get();
        return view('livewire.admins.upload-gallery');
    }
    public function store()
    {
        $data = $this->validate([
            'image_categorys_id' => 'required',
            'image' => 'required',
        ]);

        $imageName =  $data['image']->getClientOriginalName();    
        $filePath =  $data['image']->storeAs('images', $imageName, 'public');

        $categorys = new Image ;
        $categorys->image_categorys_id = $data['image_categorys_id'];
        $categorys->image = $imageName;
        $categorys->save();

        session()->flash('message','Uploaded Successfully!!');
    }
}
