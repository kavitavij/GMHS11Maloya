<?php

namespace App\Livewire\Frontend;

use Livewire\Component;

class EcoClub extends Component
{
    public function render()
    {
        return view('livewire.frontend.eco-club');
    }
}
