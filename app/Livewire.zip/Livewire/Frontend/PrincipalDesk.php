<?php

namespace App\Livewire\Frontend;

use Livewire\Component;
use App\Models\Contant;

class PrincipalDesk extends Component
{
    public $data;
    public function render()
    {
        $this->data= Contant::get()->where('type', 1);
        return view('livewire.frontend.principal-desk');
    }
}
