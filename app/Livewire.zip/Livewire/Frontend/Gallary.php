<?php

namespace App\Livewire\Frontend;

use App\Models\Image_Category;
use Livewire\Component;
use App\Models\Image;

class Gallary extends Component
{
    public $imagedata ,$image_categorys_id ;
    public function render()
    {
        return view('livewire.frontend.gallary');
    }
    public function mount(Image_Category $id)
    { 
        $this->imagedata = Image::where('image_categorys_id', $id['id'])->get();
    }
}
