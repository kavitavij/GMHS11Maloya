<?php

namespace App\Livewire\Frontend;

use Livewire\Component;

class Commitee extends Component
{
    public function render()
    {
        return view('livewire.frontend.commitee');
    }
}
