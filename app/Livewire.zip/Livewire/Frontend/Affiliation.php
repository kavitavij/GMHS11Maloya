<?php

namespace App\Livewire\Frontend;

use Livewire\Component;
use App\Models\File;


class Affiliation extends Component
{
    public $affiliationdata;
    public function render()
    {
        $this->affiliationdata = File::get()->where('type', 2);
        return view('livewire.frontend.affiliation');
    }
    public function download(File $id)
    {
        return response()->download(public_path() . '/storage/files/' . $id->file);
    }
}
