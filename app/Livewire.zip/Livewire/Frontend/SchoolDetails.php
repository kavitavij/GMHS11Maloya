<?php

namespace App\Livewire\Frontend;

use Livewire\Component;
use App\Models\School_Detail;

class SchoolDetails extends Component
{
    public $school_details;
    public function render()
    {
        $this->school_details= School_Detail::get();
        return view('livewire.frontend.school-details');
    }
}
